"""배선기(C++ -> wasm) 가 붙을 자리.

align/main.py 가 from .pnr import generate_pnr 를 하고 align/pnr/* 가
from .. import PnR 을 하므로, 이 모듈이 없으면 import align 자체가 실패한다.
앞단(1_topology, 2_primitives)은 배선기를 쓰지 않으므로 지금은 스텁이면 된다.

실수로 배치/배선 경로를 타면 조용히 이상한 값을 내는 대신 여기서 멈춘다.
"""


class _NotBuilt:
    def __init__(self, name):
        self._name = name

    def __call__(self, *a, **k):
        raise NotImplementedError(
            "PnR.%s 는 아직 브라우저에 없다. 배선기 wasm 을 붙여야 한다." % self._name)

    def __getattr__(self, k):
        return _NotBuilt("%s.%s" % (self._name, k))


def __getattr__(name):          # PEP 562
    return _NotBuilt(name)
