"""브라우저 빌드에서 빠진 모듈을 대신한다.

import align 은 배선/GUI 경로까지 최상위에서 끌어오는데, 그쪽이 쓰는
gdspy(C 확장), plotly/dash(GUI), mip(대체 배치기)는 브라우저에 없다.
앞단(1_topology, 2_primitives)과는 무관하다.

모듈 이름을 하나씩 맞히는 대신 meta path finder 를 심어 접두사 아래
아무 모듈이나 만들어낸다 (dash.dependencies, plotly.graph_objects 등).
실수로 진짜 경로를 타면 조용히 이상해지는 대신 호출 시점에 멈춘다.

사용: import browser_stubs; browser_stubs.install()
"""
import sys
import types
from importlib.abc import Loader, MetaPathFinder
from importlib.machinery import ModuleSpec

# 접두사로 맞춘다 (정확히 같거나 그 아래). align.gui 만 막고
# align.compiler 는 건드리지 않기 위해 최상위 이름이 아니라 전체 이름을 본다.
#
# align.gui 를 통째로 막는 이유: plotly 를 흉내내다 보면 끝이 없다
# (["Blugrn"] + px.colors.named_colorscales() 처럼 결과의 타입까지 요구한다).
# 라이브러리가 아니라 "우리가 안 쓰기로 한 기능"의 경계에서 자르는 게 맞다.
STUBBED = ("gdspy", "mip", "plotly", "dash", "dash_core_components",
           "dash_html_components", "align.gui")


class Missing:
    """무엇이든 받아주는 무해한 자리표시자.

    처음에는 호출되면 멈추게 했는데, plotly 같은 것은 import 시점에
    모듈 수준에서 함수를 부른다 (plotly.express.colors.named_colorscales()).
    그래서 호출도 받아주고 최대한 아무것도 아닌 것처럼 행동한다.

    진짜 위험한 자리 — 배치/배선을 실제로 부르는 PnR — 은 여기가 아니라
    align/PnR.py 에서 따로 막는다. 거기서는 소리 내어 멈춘다."""

    def __init__(self, name):
        self._n = name

    def __call__(self, *a, **k):
        return Missing(self._n + "()")

    def __getattr__(self, k):
        # 던더는 넘긴다. import 기계가 __path__ 를 물었을 때 Missing 을
        # 돌려주면 그걸 순회하려다 TypeError 로 터진다.
        if k.startswith("__") and k.endswith("__"):
            raise AttributeError(k)
        return Missing("%s.%s" % (self._n, k))

    # 최대한 무해하게: 비어 있고, 거짓이고, 순회해도 아무것도 안 나온다
    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0

    def __bool__(self):
        return False

    def __getitem__(self, k):
        return Missing("%s[%r]" % (self._n, k))

    def __repr__(self):
        return "<Missing %s>" % self._n


class _StubLoader(Loader):
    def create_module(self, spec):
        m = types.ModuleType(spec.name)
        m.__path__ = []                      # 패키지로 취급 -> 서브모듈 허용
        m.__stub__ = True
        name = spec.name

        def getattr_(attr, _n=name):
            if attr.startswith("__") and attr.endswith("__"):
                raise AttributeError(attr)
            return Missing("%s.%s" % (_n, attr))

        m.__getattr__ = getattr_
        return m

    def exec_module(self, module):
        pass


class _StubFinder(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if not any(fullname == p or fullname.startswith(p + ".") for p in STUBBED):
            return None
        return ModuleSpec(fullname, _StubLoader(), is_package=True)


def install():
    if not any(isinstance(f, _StubFinder) for f in sys.meta_path):
        # 앞에 꽂는다. 뒤에 붙이면 기본 finder 가 디스크의 진짜 파일을 먼저
        # 찾아버려서 (align/gui/mockup.py 처럼) 스텁이 무력해진다.
        sys.meta_path.insert(0, _StubFinder())
    return STUBBED
