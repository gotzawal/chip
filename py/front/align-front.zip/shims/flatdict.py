"""flatdict.FlatDict 대체.

align 은 FlatDict 를 세 곳에서 쓰는데, 전부 같은 모양이다:
    param = FlatDict(d)
    arg_str = '_'.join(str(k)+':'+str(param[k]) for k in sorted(param.keys()))
    key = sha256(arg_str) % 10**8

**이 해시가 생성되는 서브회로 이름에 들어간다.** 그래서 키 형식이 원본과
정확히 같아야 한다. 대충 만들면 이름이 달라지고, 네이티브 출력과 대조가 깨진다.
test-flatdict.py 가 진짜 flatdict 와 대조한다.

플레인 FlatDict 의 규칙: 중첩 dict 만 delimiter(기본 ':') 로 평탄화하고,
리스트/튜플 등 나머지는 잎(leaf) 값으로 둔다. (리스트까지 펴는 것은 FlatterDict 다)
"""

DELIMITER = ":"


class FlatDict:
    def __init__(self, value=None, delimiter=DELIMITER, dict_class=dict):
        self._delimiter = delimiter
        self._values = dict_class()
        if value is not None:
            self.update(value)

    # --- 평탄화 ---
    def _flatten(self, value, prefix=""):
        for k, v in value.items():
            key = "%s%s%s" % (prefix, self._delimiter, k) if prefix else str(k)
            if isinstance(v, dict) and v:
                self._flatten(v, key)
            else:
                # 빈 dict 는 잎으로 둔다 (원본도 키를 잃지 않는다)
                self._values[key] = v

    def update(self, value=None, **kwargs):
        if value:
            self._flatten(value)
        if kwargs:
            self._flatten(kwargs)

    # --- 매핑 인터페이스 (쓰이는 것만) ---
    def keys(self):
        return self._values.keys()

    def values(self):
        return self._values.values()

    def items(self):
        return self._values.items()

    def __getitem__(self, key):
        return self._values[key]

    def __setitem__(self, key, value):
        self._values[key] = value

    def __contains__(self, key):
        return key in self._values

    def __iter__(self):
        return iter(self._values)

    def __len__(self):
        return len(self._values)

    def __eq__(self, other):
        if isinstance(other, FlatDict):
            return self._values == other._values
        return self._values == other

    def __repr__(self):
        return "<FlatDict %r>" % self._values

    def as_dict(self):
        return dict(self._values)


class FlatterDict(FlatDict):
    """리스트/튜플까지 펴는 변형. align 은 안 쓰지만 이름만 맞춰 둔다."""

    def _flatten(self, value, prefix=""):
        items = value.items() if isinstance(value, dict) else enumerate(value)
        for k, v in items:
            key = "%s%s%s" % (prefix, self._delimiter, k) if prefix else str(k)
            if isinstance(v, (dict, list, tuple)) and len(v):
                self._flatten(v, key)
            else:
                self._values[key] = v
