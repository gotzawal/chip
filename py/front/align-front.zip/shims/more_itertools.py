"""more_itertools 대체.

align/schema/constraint.py 는 `import more_itertools as itertools` 로 별칭을 걸고
combinations / product / pairwise 세 개만 쓴다. 셋 다 표준 itertools 에 있다
(pairwise 는 3.10+). more_itertools 는 표준 itertools 를 재수출하므로
동작이 같다. 휠 하나를 줄이려고 둔다.
"""
from itertools import *          # noqa: F401,F403
from itertools import combinations, pairwise, product   # noqa: F401
